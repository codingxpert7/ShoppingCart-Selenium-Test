import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


public class HomePageTest {

	WebDriver driver;
	HomePageFactory homePage;

	@BeforeTest
	public void setup(){
		System.setProperty("webdriver.chrome.driver", "/usr/lib/chromium-browser/chromedriver");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://tutorialsninja.com/demo/index.php?route=common/home");
	}

	@Test(priority=0)
	public void test_homepage_successfull(){
		homePage = new HomePageFactory(driver);
		homePage.clickShoppingCart();
		HomePageNavigationSuccess success = new HomePageNavigationSuccess(driver);
		Assert.assertTrue(success.checkForShoppingCart());	
	}
}
