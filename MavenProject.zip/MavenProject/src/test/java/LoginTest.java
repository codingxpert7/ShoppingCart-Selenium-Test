import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


public class LoginTest {

	WebDriver driver;
	LoginPageFactory objLogin;
	LoginSuccess myAccount;

	@BeforeTest
	public void setup(){
		System.setProperty("webdriver.chrome.driver", "/usr/lib/chromium-browser/chromedriver");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://tutorialsninja.com/demo/index.php?route=account/login");
	}

	@Test(priority=0)
	public void test_login(){
		//Create Login Page object
		objLogin = new LoginPageFactory(driver);
		objLogin.loginWebsite("ricky@gmail.com", "Krsna7*7");
		myAccount = new LoginSuccess(driver);
		Assert.assertTrue(myAccount.checkLoggedIn());	

	}

}
