import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


public class RegistrationTest {

	WebDriver driver;
	RegistrationPageFactory objLogin;
	RegistrationSuccess registrationSuccess;

	@BeforeTest
	public void setup(){
		System.setProperty("webdriver.chrome.driver", "/usr/lib/chromium-browser/chromedriver");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://tutorialsninja.com/demo/index.php?route=account/register");
	}

	@Test(priority=0)
	public void test_registration_successfull(){
		//Create Login Page object
		objLogin = new RegistrationPageFactory(driver);
		objLogin.register("ricky", "ponting", "rickyponting@gmail.com","9876543219", "Password7*7", "Password7*7");
		registrationSuccess = new RegistrationSuccess(driver);
		Assert.assertTrue(registrationSuccess.checkRegistered());	
	}
}
