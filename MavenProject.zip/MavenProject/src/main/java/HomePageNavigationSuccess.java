import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class HomePageNavigationSuccess {

	WebDriver driver;
	@FindBy(tagName = "h1")
	WebElement headerTitle;
	
	
	public HomePageNavigationSuccess(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public boolean checkForShoppingCart(){
		
		WebElement cart = driver.findElement(By.xpath("//*[@id=\"content\"]/h1"));
		return cart.getText().equals("Shopping Cart");
	}
}
