import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class RegistrationPageFactory {

	WebDriver driver;
	@FindBy(name="firstname")
	WebElement firstName;

	@FindBy(name="lastname")
	WebElement lastName;

	@FindBy(name="email")
	WebElement emailId;

	@FindBy(name="telephone")
	WebElement telephone;

	@FindBy(name="password")
	WebElement password;

	@FindBy(name="confirm")
	WebElement confirm;

	@FindBy(name="agree")
	WebElement agree;


	public RegistrationPageFactory(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void setFirstName(String fname){
		firstName.sendKeys(fname);
	}

	public void setLastName(String lname){
		lastName.sendKeys(lname);
	}

	public void setEmailId(String email){
		emailId.sendKeys(email);
	}


	public void setTelephone(String phone){
		telephone.sendKeys(phone);
	}


	public void setPassword(String pwd){
		password.sendKeys(pwd);
	}

	public void setConfirm(String confirmStr){
		confirm.sendKeys(confirmStr);
	}


	public void setAgree(){
		driver.findElement(By.name("agree")).click();

	}


	public void clickRegister(){
		WebElement submit = driver.findElement(By.cssSelector("[type='submit']"));
		submit.click();
	}

	public void register(String firstName, String lastName, String email, String phone, String pwd, String confirm){
		this.setFirstName(firstName);
		this.setLastName(lastName);
		this.setEmailId(email);
		this.setTelephone(phone);
		this.setConfirm(confirm);
		this.setPassword(pwd);
		this.setAgree();
		this.clickRegister();

	}
}
