import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;


public class AddCartFactory {
	WebDriver driver;
	
	public AddCartFactory(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void addToCart(){
		WebElement macbook = driver.findElement(By.xpath("//*[@id='content']/div[2]/div[1]/div/div[3]/button[1]"));
		macbook.click();
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		WebElement cart = driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[4]/a"));
		cart.click();
	}
	
}