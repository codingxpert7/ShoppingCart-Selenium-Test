import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class HomePageFactory {

	WebDriver driver;
	@FindBy(name="search")
	WebElement searchBox;
	
	@FindBy(id="cart")
	WebElement cartSection;
	
	
	@FindBy(linkText = "https://tutorialsninja.com/demo/index.php?route=checkout/cart")
	WebElement shoppingCart;
	
	@FindBy(linkText = "https://tutorialsninja.com/demo/index.php?route=checkout/checkout")
	WebElement checkOut;
	
	@FindBy(linkText = "https://tutorialsninja.com/demo/index.php?route=account/wishlist")
	WebElement wishList;
	
	@FindBy(linkText = "https://tutorialsninja.com/demo/index.php?route=account/register")
	WebElement registerLink;
	
	@FindBy(linkText = "https://tutorialsninja.com/demo/index.php?route=account/login")
	WebElement loginLink;
	
	public HomePageFactory(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void clickShoppingCart(){
		WebElement cart = driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[4]/a"));
		cart.click();
	}
	
}
