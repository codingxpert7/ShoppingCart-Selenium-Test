import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;


public class CheckoutCartFactory {
	WebDriver driver;
	
	public CheckoutCartFactory(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void checkout(){
		WebElement macbook = driver.findElement(By.xpath("//*[@id='content']/div[2]/div[1]/div/div[3]/button[1]"));
		macbook.click();
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		WebElement checkout = driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[5]/a"));
		checkout.click();
	}
	
}