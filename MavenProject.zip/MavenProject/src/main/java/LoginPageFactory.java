import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class LoginPageFactory {

	WebDriver driver;
	@FindBy(name="email")
	WebElement emailId;

	@FindBy(name="password")
	WebElement passwordELement;


	public LoginPageFactory(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void setUserName(String strUserName){
		emailId.sendKeys(strUserName);

	}

	public void setPassword(String strPassword){
		passwordELement.sendKeys(strPassword);
	}

	public void clickLogin(){
		WebElement submit = driver.findElement(By.cssSelector("[type='submit']"));
		submit.click();
	}

	public void loginWebsite(String strUserName,String strPasword){
		this.setUserName(strUserName);
		this.setPassword(strPasword);
		this.clickLogin();

	}
}
