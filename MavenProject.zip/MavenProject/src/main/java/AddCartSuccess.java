import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class AddCartSuccess {

	WebDriver driver;
	
	private String selectedProduct;
	public AddCartSuccess(WebDriver driver, String selectedProduct){
		this.driver = driver;
		this.selectedProduct = selectedProduct;
		PageFactory.initElements(driver, this);
	}
	
	public boolean isAddedToCart(){
        List<WebElement> aTags = driver.findElements(By.tagName("a"));
        
        for (WebElement element : aTags) {
        	 if (element.getText().equals(selectedProduct)) {
        		 return true;
        	 }
        }
        return false;
	}
}
