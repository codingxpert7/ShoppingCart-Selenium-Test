import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class SearchPageFactory {

	WebDriver driver;
	@FindBy(name="search")
	WebElement searchBar;
	
	
	public SearchPageFactory(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void setSearchItem(String itemName){
		searchBar.sendKeys(itemName);
	}
	
	public void clickSearch(){
		WebElement submit = driver.findElement(By.xpath("//*[@id=\"search\"]/span/button"));
		submit.click();
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		WebElement detail = driver.findElement(By.xpath("//*[@id=\"content\"]/div[3]/div/div/div[1]/a"));
		detail.click();
	}
	
}
